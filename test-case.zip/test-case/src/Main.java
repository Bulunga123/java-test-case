import java.util.Scanner;
//Bongani Bulunga
public class Main {

	public static void main(String[] args) 
	{
		System.out.println("enter a number to convert to hexadecimal?:");
		Scanner sc = new Scanner(System.in);
		int input;
	    int remainder;
	  
		input = sc.nextInt();
		char[] hex = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
		String hexa ="";
			
			while(input > 0 && input < 10000)
			{
				remainder = input % 16;
				hexa = hex[remainder] + hexa;
				input = input/16;	
			}
			System.out.print("Converted to hexadecimal:" + hexa);
	}
}
